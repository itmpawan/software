<?php
    class db{

        private $hostname = 'localhost';
        private $database = 'software';
        private $username = 'root';
        private $password = 'root';

        protected $db;

        public function __construct(){
            try{
                /*
                    * Create Database connection
                */
                $this->db = new PDO("mysql:host=" . $this->hostname. ";dbname=" .$this->database, $this->username, $this->password);
                
            } catch(PDOExeption $e){
                echo "Connection Problem: " . $e->getMessage();
            }
        }

    }
?>