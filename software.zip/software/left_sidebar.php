<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li class="sidebar-search">
                
            </li>
            <li>
                <a href="dashboard.php" class="active"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
            </li>
            <li><a href="customers.php"><i class="fa fa-users fa-fw"></i> Manage Customers</a>
            </li>
            <li><a href="systems.php"><i class="fa fa-lightbulb-o fa-fw"></i> Manage Systems</a>
            </li>
            <li><a href="fields.php"><i class="fa fa-tasks fa-fw"></i> Manage Fields</a>
            </li>
            <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
            </li>
            
        </ul>
    </div>
</div>