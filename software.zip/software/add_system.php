<?php include "init.php"; //echo 'sparsh@2016'; ?>
<?php if(!isset($_SESSION['id'])): ?>
<?php header("location:index.php"); ?>
<?php endif; ?>
<?php 
if(isset($_POST['system'])){

 $data = [
     'sys_cap'       => $_POST['sys_cap'],
     'sys_no'       => $_POST['sys_no'],
     'model'       => $_POST['model'],
     'ins_date'       => $_POST['ins_date'],
     'dealer'       => $_POST['dealer'],
     'to_whom'       => $_POST['to_whom'],
     'place'       => $_POST['place'],
     'remarks'       => $_POST['remarks'],
     'status'       => $_POST['status'],
     'sys_cap_error'    => '',
     'sys_no_error'    => '',
     'model_error'    => '',
     'message' => ''

 ];

if(empty($data['sys_cap'])){
    $data['sys_cap_error'] = "SYS. CAP. field is required.";
}
 
if(empty($data['sys_no'])){
    $data['sys_no_error'] = "SYS. No. field is required.";
}

if(empty($data['model'])){
    $data['model_error'] = "Model field is required.";
}
    /*
        * Submit the system form
    */ 

    if(empty($data['sys_cap_error']) && empty($data['sys_no_error']) && empty($data['model_error']) ){

        if($dbObject->queryExecute("SELECT * FROM systems WHERE sys_cap = ? AND sys_no = ? AND model = ?", [$data['sys_cap'] , $data['sys_no'], $data['model']] )){
            if($dbObject->countRows() == 0){
                $date = date('Y-m-d H:i:s');
                $dbObject->queryExecute("INSERT INTO `systems` (`sys_cap`, `sys_no`, `model`, `ins_date`, `dealer`, `to_whom`,
                `place`, `remarks`, `created_at`, `status`) VALUES (?,?,?,?,?,?,?,?,?,?)", [ $data['sys_cap'] , $data['sys_no'], $data['model'],
                $data['ins_date'] , $data['dealer'], $data['to_whom'], $data['place'] , $data['remarks'], $date, $data['status'] ]);

                $error = false;
                $data['message'] = "<strong>Success!</strong> record has been added successfully.";  
            }else{

                $error = true;
                $data['message'] = "<strong>Sorry!</strong> record already exist.";  
            }
        }
    }


}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Add System - SR Enterprises</title>
 
        <link rel="icon" href="assets/img/SR-logo.png" type="image/png" sizes="16x16">

        <!-- Bootstrap Core CSS -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="assets/css/startmin.css" rel="stylesheet">
      
        <link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
     

    </head>
    <body>

        <div id="wrapper">
            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
              

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i>SR Enterprises</a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                 
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> Admin <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            
                            <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                  <!-- /.navbar-top-links -->
                  <?php include('left_sidebar.php');?>
                
            </nav>

            <div id="page-wrapper" style="margin-top:50px;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Add New System</h1>                         
                        </div>                               
                        <!-- /.col-lg-12 -->
                    </div>
                          <!-- /.row -->
                          <div class="row">
                        <div class="col-lg-12">

                        <?php if(!empty($data['message'])): ?>
                            <div class="alert <?php if($error == false): ?> alert-success <?php endif; ?> <?php if($error == true): ?> alert-danger<?php endif; ?> alert-dismissible fade in">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo $data['message']; ?>
                            </div>                                
                        <?php endif; ?>


                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    System Stock Form
                                </div>
                              

                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form role="form" method="post">
                                               
                                                <div class="form-group <?php if(!empty($data['sys_cap_error'])): ?> has-error<?php endif; ?>">
                                                    <label>SYS. CAP. <span style="color:red">*</span></label>
                                                    <input class="form-control" name="sys_cap" placeholder="Enter SYS CAP here.." value="<?php echo $data['sys_cap'];?>">
                                                    <?php if(!empty($data['sys_cap_error'])): ?>
                                                        <label class="control-label" for="inputError"><?php echo $data['sys_cap_error']; ?></label>
                                                      <?php endif; ?>
                                                </div>
                                                <div class="form-group <?php if(!empty($data['sys_no_error'])): ?> has-error<?php endif; ?>">
                                                    <label>SYS. NO. <span style="color:red">*</span></label>
                                                    <input class="form-control" name="sys_no" placeholder="Enter SYS number here.." value="<?php echo $data['sys_no'];?>">
                                                    <?php if(!empty($data['sys_no_error'])): ?>
                                                        <label class="control-label" for="inputError"><?php echo $data['sys_no_error']; ?></label>
                                                      <?php endif; ?>
                                                </div>
                                            
                                                <div class="form-group <?php if(!empty($data['model_error'])): ?> has-error<?php endif; ?>">
                                                    <label>MODEL  <span style="color:red">*</span></label>
                                                    <input class="form-control" name="model" placeholder="Enter model here.." value="<?php echo $data['model'];?>">
                                                    <?php if(!empty($data['model_error'])): ?>
                                                        <label class="control-label" for="inputError"><?php echo $data['model_error']; ?></label>
                                                      <?php endif; ?>
                                                </div>
                                                <div class="form-group">
                                                    <label>INS. DATE</label>
                                                    <input class="form-control" id="installdatepicker" name="ins_date" placeholder="Enter installment date here.." value="<?php echo $data['ins_date'];?>">
                                               
                                                </div>
                                                <div class="form-group">
                                                    <label>DEALER</label>
                                                    <input class="form-control" name="dealer" placeholder="Enter dealer here.."  value="<?php echo $data['dealer'];?>">
                                               
                                                </div>
                                                <div class="form-group">
                                                    <label>TO WHOM</label>
                                                    <input class="form-control" name="to_whom" placeholder="Enter to whom here.."  value="<?php echo $data['to_whom'];?>">
                                               
                                                </div>
                                                <div class="form-group">
                                                    <label>PLACE</label>
                                                    <input class="form-control" name="place" placeholder="Enter place here.."  value="<?php echo $data['place'];?>">
                                               
                                                </div>
                                                <div class="form-group">
                                                    <label>REMARKS</label>
                                                    <input class="form-control" name="remarks" placeholder="Enter remark here.." value="<?php echo $data['remarks'];?>">
                                               
                                                </div>
                                                <div class="form-group">
                                                    <label>Status <span style="color:red">*</span></label>
                                                    <select name="status" class="form-control">
                                                        <option <?php if($data['status'] == 'Active'): ?> selected <?php endif;?> value="Active">Active</option>
                                                        <option <?php if($data['status'] == 'InActive'): ?> selected <?php endif;?> value="InActive">InActive</option>
                                                     
                                                    </select>
                                                </div>
                                             
                                                <button type="submit" name="system" class="btn btn-primary">Submit</button>
                                                <button type="reset" class="btn btn-warning">Reset</button>
                                            </form>
                                        </div>
                                    
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->


                     

                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="assets/js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="assets/js/bootstrap.min.js"></script>

        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

          <script>
      
        $('#installdatepicker').datepicker({  });
    </script>
  
    </body>
</html>